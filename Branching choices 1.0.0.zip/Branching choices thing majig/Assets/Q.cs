﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Q : MonoBehaviour {

    public static int currentQA;
    public Text Question;
    string output = null;
    List<bool> Answers = new List<bool>();

	// Use this for initialization
	void Start () {
		currentQA = 0;
	}
	
	// Update is called once per frame
	void Update () {
        switch(currentQA){
            case 0:
                output = "Do You Like Apples or Bananas?";
                if(Input.GetKeyDown("left")){
                    Answers.Add(false);
                    currentQA++;
                    }
                else if(Input.GetKeyDown("right")){
                    Answers.Add(true);
                    currentQA++;
                    }
                break;
		}
        if(currentQA == 0){
            Question.text = output;
	    }
        else{
            if(Answers[0] == false){
                Question.text = output + "false";

            }
            else{
                Question.text = output + "true";            
            }
        }
    }
}

/*
 * private List<string> list = new List<string>(); // You'd replace "string" with the type of object you'd like to put in the list.

public void ListStuff() {

    list.Add("A new string"); // Adds an element to the list.
    list.Remove("A new string"); // Removes the element from the list, if it's in there.
    list.Clear(); // Completely empties the list.
    int num = list.Count; // Number of items in the list.
    list.Contains("A new string"); // Returns true or false based on whether the given string is in the list.

}
*/
