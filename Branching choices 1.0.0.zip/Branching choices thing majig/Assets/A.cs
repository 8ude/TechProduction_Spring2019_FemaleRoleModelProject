﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class A : MonoBehaviour {
    /*
    public static int currentQA;
    public Text Answer;
    private Text text;
    string output = null;

	// Use this for initialization
	void Start () {
		output = "Do you like Apples or Bananas?";
	}
	
	// Update is called once per frame
	void Update () {
		Question.text = output;
	}
    */
}